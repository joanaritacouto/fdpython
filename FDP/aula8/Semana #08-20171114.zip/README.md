# Bibliografia para a semana 08.

Além dos slides e guião disponibilizados nesta pasta,
sugere-se a leitura e resposta aos exercícios
de [2, cap. 12] e [2, sec. 10.26-10.28],
ou de [1, caps. 11 e 12].
Como de costume, recomenda-se a execução e análise dos exemplos
incluídos na referência [2].

[1] [Think Python 2e](http://greenteapress.com/wp/think-python-2e/)

[2] [How to Think Like a Computer Scientist: Interactive Edition](http://interactivepython.org/courselib/static/thinkcspy/index.html)


