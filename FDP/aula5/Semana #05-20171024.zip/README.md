# Bibliografia para semana 05.

Além dos slides e guião disponibilizados nesta pasta,
sugere-se a leitura e resposta aos exercícios de [2, ch. 6],
ou de [1, ch. 3].
Na referência [2], recomenda-se especialmente o estudo de alguns exemplos
que estão em caixas "Codelens".
Estas caixas permitem executar as instruções passo-a-passo e visualizar a
evolução das variáveis na memória à medida que o programa é executado.


[1] [Think Python 2e](http://greenteapress.com/wp/think-python-2e/)
[2] [How to Think Like a Computer Scientist: Interactive Edition](http://interactivepython.org/courselib/static/thinkcspy/index.html)


