x = int(input('Um numero: '))

if x > 0:
  print('positivo')
  print('ainda dentro da decisao')

print('END')
