x = int(input('numero: '))

r = x % 2
if r == 0:
  print('par')
else:
  print('impar')

print('o programa continua...')

if x == 0:
  print('zero')
else:
  print('diferente de zero')

print('o programa ainda continua...')
