x = int(input('x: '))
y = int(input('y: '))

if x > y:
  print('x e maior: ', x)

elif y > x:
  print('y e maior: ', y)
 
else:
  print('iguais')

print('END')

