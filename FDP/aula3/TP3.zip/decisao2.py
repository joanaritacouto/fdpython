x = int(input('Um numero: '))

y = x > 0
print('antes do if, o valor de y e ', y)

if y:
  print('positivo')
  print('ainda dentro da decisao')

print('END')
