x = int( input('number: '))

if x > 0:
   print('Positive')
   print('more things inside if')
   print('and more...')

print('the program continues here...')
