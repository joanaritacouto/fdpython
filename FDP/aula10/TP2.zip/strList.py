def upperList(lst):
    lst2 = []
    for v in lst:
        v2 = v.upper()
        lst2.append(v2)
    return lst2
