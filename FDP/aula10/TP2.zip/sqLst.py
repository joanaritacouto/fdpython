def squareList(lst):
    lst2 = []
    for v in lst:
        v2 = v**2
        lst2.append(v2)
    return lst2

