# Exemplo sobre strings
# AN 2017
s = 'ola aveiro'

print(s)

for x in s:
  print(x)

s2 = s.replace('a', 'Z')
print('depois s', s)
print('depois s2', s2)