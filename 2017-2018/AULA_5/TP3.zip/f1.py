# exemplos de funcoes sem valor de retorno
# AN 2017

def myFunc():
  print('funcoes1')
  print('funcoes2')

def myFunc2():
  print('mais funcoes1')
  print('mais funcoes2')
  
for i in range(5):
  myFunc()

myFunc2()