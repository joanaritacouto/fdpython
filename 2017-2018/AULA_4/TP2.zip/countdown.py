# Exemplo 1 na turma TP2
# Escrever os números de 10 a 0.
# JMR 2017

n = 10
while n>=0:
    print(n)
    n = n-1

print("FIM")

