# impressao dos numeros de 10 ate 0
# AN 2017

#inicializacao
k = 10 

while k >= 0:
  print(k)
  k = k - 1

else:
  print('no fim, k = ', k)

print('FIM')
